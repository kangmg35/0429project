package p0429;

public class exam01 {

	public static void main(String[] args) {
		System.out.println("첫 Java 프로그램입니다.");
		System.out.print("화면에 출력하고 있습니다.");

	}

}
