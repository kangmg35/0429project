package p0429;

import java.util.Scanner;

public class exam09 {

	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		System.out.print("성 :  ");
		String s1=s.next();
		System.out.print("이름 : ");
		String s2=s.next();
		
		System.out.printf("안녕하세요. %s%s 씨.",s1,s2);
		
	}

}
