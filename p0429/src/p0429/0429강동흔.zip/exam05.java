package p0429;

import java.util.Scanner;

public class exam05 {

	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		
		System.out.print("정숫값 : ");
		int num1=s.nextInt();
		System.out.printf("%d를 입력했습니다.",num1);
		
	}

}
