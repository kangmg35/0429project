package p0429;

public class exam02 {

	public static void main(String[] args) {
		System.out.println("홍");
		System.out.println("길");
		System.out.println("동");

	}

}
