package p0429;

import java.util.Scanner;

public class exam11 {

	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		System.out.print("정숫값: ");
		int num1=s.nextInt();
		
		if(num1<0){
			System.out.print("이 값은 음의 값입니다.");}
		else{
			System.out.printf("정숫값:%d",num1);}
		
			
			
		}
	}


