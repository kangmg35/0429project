package p0429;

public class exam04 {

	public static void main(String[] args) {
		int x=63;
		int y=18;
		int z=52;
		
		System.out.printf("x의 값은 %d입니다.\n",x);
		System.out.printf("y의 값은 %d입니다.\n",y);
		System.out.printf("z의 값은 %d입니다.\n",z);
		System.out.printf("합계는 %d입니다.\n",x+y+z);
		System.out.printf("평균은 %d입니다.\n",(x+y+z)/3);
	}

}
