package p0429;

import java.util.Scanner;

public class exam10 {

	public static void main(String[] args) {
		Scanner s= new Scanner(System.in);
		System.out.print("주소 : ");
		String s1=s.next();
		String s2=s.next();
		
		System.out.printf("주소는 %s %s입니다.",s1,s2);
		
	}

}
